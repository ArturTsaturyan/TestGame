export const GAMES = "GAMES";
export const GAMENAMES = "GAMENAMES";
